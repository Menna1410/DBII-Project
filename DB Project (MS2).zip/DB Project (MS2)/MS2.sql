﻿CREATE DATABASE MS2
USE MS2

--(2.1)
-->a
GO
CREATE PROC CreateAllTables

AS
CREATE TABLE SystemUser (
username varCHAR(20) PRIMARY KEY,
password varchar(20)
)

CREATE TABLE SystemAdmin (
username varchar(20) foreign key references SystemUser(username) on update cascade on delete cascade,
sa_id Int Identity, 
primary key(sa_id,username),
name varchar(20)
);

CREATE Table SportsAssociationManager(
username varchar(20) foreign key references SystemUser(username) on update cascade on delete cascade,
sam_id INt Identity,
primary key(sam_id,username),
name varchar(20)
)

Create Table Fan(
username varchar(20) foreign key references SystemUser(username) on update cascade on delete cascade, 
national_ID int,
primary key (national_ID,username),
birth_date DATE,
Status BIT,
address varchar(20),
name varchar(20),
phoneNo varchar(20)
)

Create Table ClubRepresentative (
username varchar(20) foreign key references SystemUser(username) on update cascade on delete cascade, 
cr_id Int Identity,
Primary Key (cr_id, username),
name varchar(20)
)

CREATE TABLE Match(
m_id int PRIMARY KEY Identity,
end_time TIME,
start_time TIME,
stadium_id int FOREIGN KEY REFERENCES Stadium(s_id) on update cascade on delete cascade 
)

CREATE TABLE StadiumManager(
username VARCHAR (20) FOREIGN KEY REFERENCES SystemUser(username) on update cascade on delete cascade ,
sm_id int identity,
Primary key (sm_id, username),
name VARCHAR(20)
)

CREATE TABLE Ticket(
Status bit , 
t_id int PRIMARY KEY,
match_id int FOREIGN KEY references Match(m_id) on update cascade on delete cascade,
Username VARCHAR(20) FOREIGN KEY references Fan(username) on update cascade on delete cascade,
)

CREATE TABLE Club (
name Varchar(20),
location Varchar(20) ,
c_id INT PRIMARY KEY Identity, 
host_id INT FOREIGN KEY references MATCH(m_id) on update cascade on delete cascade, 
guest_id INT Foreign KEY references MATCH(m_id) on update cascade on delete cascade
)

create table Stadium (
username VARCHAR (20) FOREIGN KEY REFERENCES StadiumManager(username) on update cascade on delete cascade,
stadManager_id VARCHAR (20) FOREIGN KEY REFERENCES StadiumManager(username) on update cascade on delete cascade, 
s_id int IDENTITY,
name varchar(20),
capacity int,
location Varchar(20),
status bit ,
PRIMARY KEY (s_id));


create table HostRequest(
hr_id int IDENTITY,
m_id int,
status varchar(20),
cr_username Varchar(20) ,
sm_username varchar(20),
PRIMARY KEY (hr_id),
FOREIGN KEY (cr_username) References  ClubRepresentitive( username )  ON Update cascade ON delete cascade,
FOREIGN KEY (sm_username) References  StadiumManager (username) ON Update cascade ON delete cascade
);

--(2.1)
-->b
Go;
CREATE PROC dropAllTables 
AS
DROP table SystemUser;
DROP table SystemAdmin;
DROP table SportsAssociationManager;
DROP table Fan;
DROP table ClubRepresentative;
DROP table Match;
DROP table StadiumManager;
DROP table Ticket;
DROP table Club;
DROP table Stadium;
DROP table HostRequest;

--(2.1)
-->c
--"Skip"

--(2.1)
-->d

GO
Create PROC clearAllTables
AS
TRUNCATE table SystemUser;
TRUNCATE table SystemAdmin;
TRUNCATE table SportsAssociationManager;
TRUNCATE table Fan;
TRUNCATE table ClubRepresentative;
TRUNCATE table Match;
TRUNCATE table StadiumManager;
TRUNCATE table Ticket;
TRUNCATE table Club;
TRUNCATE table Stadium;
TRUNCATE table HostRequest;

--(2.2)
-->a






















